"""
Movie Recommendation System — Flask API Backend
================================================
Run locally:  python app.py
Deploy:       Use Railway / Render / Heroku (see README)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import pandas as pd
import numpy as np
import os

app = Flask(__name__)
CORS(app)

# ─── Load Models ────────────────────────────────────────────────────────────

MODEL_DIR = os.path.join(os.path.dirname(__file__), 'model_files')

print("Loading models...")
with open(os.path.join(MODEL_DIR, 'svd_model.pkl'), 'rb') as f:
    svd_model = pickle.load(f)

with open(os.path.join(MODEL_DIR, 'cosine_sim.pkl'), 'rb') as f:
    cosine_sim = pickle.load(f)

movies_df  = pd.read_csv(os.path.join(MODEL_DIR, 'movies.csv'))
ratings_df = pd.read_csv(os.path.join(MODEL_DIR, 'ratings.csv'))
title_to_index = pd.Series(movies_df.index, index=movies_df['title'])

print("✅ Models loaded successfully!")


# ─── Helper Functions ────────────────────────────────────────────────────────

def get_cf_recommendations(user_id: int, n: int = 10) -> list:
    """Collaborative Filtering: recommend movies for a given user."""
    all_ids  = movies_df['movie_id'].tolist()
    rated_ids = ratings_df[ratings_df['user_id'] == user_id]['movie_id'].tolist()
    unrated  = [m for m in all_ids if m not in rated_ids]

    preds = [(mid, svd_model.predict(user_id, mid).est) for mid in unrated]
    preds.sort(key=lambda x: x[1], reverse=True)

    top_ids  = [p[0] for p in preds[:n]]
    pred_map = dict(preds)

    result = movies_df[movies_df['movie_id'].isin(top_ids)].copy()
    result['predicted_rating'] = result['movie_id'].map(pred_map)
    result = result.sort_values('predicted_rating', ascending=False)
    return result[['movie_id', 'title', 'genres_str', 'predicted_rating']].to_dict(orient='records')


def get_cb_recommendations(movie_title: str, n: int = 10) -> list:
    """Content-Based Filtering: find movies similar by genre."""
    if movie_title not in title_to_index.index:
        return []
    idx = title_to_index[movie_title]
    scores = list(enumerate(cosine_sim[idx]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)
    scores = [s for s in scores if s[0] != idx][:n]
    indices = [s[0] for s in scores]
    result  = movies_df.iloc[indices][['movie_id', 'title', 'genres_str']].copy()
    result['similarity'] = [round(s[1], 3) for s in scores]
    return result.to_dict(orient='records')


def search_movies(query: str, n: int = 10) -> list:
    """Search movies by title substring."""
    mask = movies_df['title'].str.contains(query, case=False, na=False)
    return movies_df[mask][['movie_id', 'title', 'genres_str']].head(n).to_dict(orient='records')


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    return jsonify({
        'message': '🎬 Movie Recommender API',
        'version': '1.0.0',
        'endpoints': {
            'GET /api/recommend/user/<user_id>?n=10': 'Collaborative Filtering',
            'GET /api/recommend/movie?title=<title>&n=10': 'Content-Based Filtering',
            'GET /api/movies/search?q=<query>': 'Search movies',
            'GET /api/movies/popular?n=20': 'Popular movies',
            'GET /api/users/valid': 'Valid user IDs',
        }
    })


@app.route('/api/recommend/user/<int:user_id>')
def recommend_user(user_id):
    n = min(int(request.args.get('n', 10)), 50)
    valid = ratings_df['user_id'].unique().tolist()
    if user_id not in valid:
        return jsonify({'error': f'User {user_id} not found. Valid range: 1–943'}), 404
    recs = get_cf_recommendations(user_id, n)
    return jsonify({
        'user_id': user_id,
        'method': 'Collaborative Filtering (SVD)',
        'count': len(recs),
        'recommendations': recs
    })


@app.route('/api/recommend/movie')
def recommend_movie():
    title = request.args.get('title', '').strip()
    n = min(int(request.args.get('n', 10)), 50)
    if not title:
        return jsonify({'error': 'Provide ?title=MovieName'}), 400
    recs = get_cb_recommendations(title, n)
    if not recs:
        return jsonify({'error': f'"{title}" not found. Use /api/movies/search?q=... to find the exact title.'}), 404
    return jsonify({
        'movie': title,
        'method': 'Content-Based Filtering (Cosine Similarity)',
        'count': len(recs),
        'recommendations': recs
    })


@app.route('/api/movies/search')
def movie_search():
    q = request.args.get('q', '').strip()
    n = min(int(request.args.get('n', 10)), 50)
    if not q:
        return jsonify({'error': 'Provide ?q=search_term'}), 400
    results = search_movies(q, n)
    return jsonify({'query': q, 'count': len(results), 'movies': results})


@app.route('/api/movies/popular')
def popular_movies():
    n = min(int(request.args.get('n', 20)), 100)
    stats = ratings_df.groupby('movie_id')['rating'].agg(['mean', 'count'])
    stats = stats[stats['count'] >= 50].sort_values('mean', ascending=False).head(n)
    stats = stats.reset_index()
    result = stats.merge(movies_df[['movie_id', 'title', 'genres_str']], on='movie_id')
    result.columns = ['movie_id', 'avg_rating', 'num_ratings', 'title', 'genres']
    result['avg_rating'] = result['avg_rating'].round(2)
    return jsonify({'count': len(result), 'popular_movies': result.to_dict(orient='records')})


@app.route('/api/users/valid')
def valid_users():
    users = sorted(ratings_df['user_id'].unique().tolist())
    return jsonify({'total_users': len(users), 'sample_user_ids': users[:30]})


@app.route('/api/stats')
def stats():
    return jsonify({
        'total_movies': int(len(movies_df)),
        'total_ratings': int(len(ratings_df)),
        'total_users': int(ratings_df['user_id'].nunique()),
        'avg_rating': round(float(ratings_df['rating'].mean()), 2),
        'rating_scale': '1–5 stars'
    })


# ─── Run ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
